import { useEffect, useState } from "react";
const api = (p, o) => fetch("/api" + p, o).then(async (r) => { const j = await r.json().catch(() => ({})); if (!r.ok) throw Object.assign(new Error(j.error || "Request failed"), { data: j }); return j; });
const Err = ({ retry }) => <div className="card" role="alert">Could not load data. Check that the server and MongoDB are running. <button onClick={retry}>Retry</button></div>;
const post = (p, body) => api(p, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body || {}) });
const Pill = ({ l }) => <span className={`pill l${l}`}>{l ? `Support level ${l}` : "No flag"}</span>;

function Chart({ s, base, classAvg }) {
  const W = 320, H = 150, p = 24, X = (i) => p + (i * (W - 2 * p)) / 7, Y = (v) => H - p - ((v - 40) * (H - 2 * p)) / 60;
  const pts = (a) => a.map((v, i) => `${X(i)},${Y(v)}`).join(" ");
  return (<>
    <svg viewBox={`0 0 ${W} ${H}`} role="img" aria-label="Maths marks against own usual level">
      <polyline fill="none" stroke="var(--mu)" strokeDasharray="4 3" points={pts(classAvg)} />
      <line x1={p} x2={W - p} y1={Y(base)} y2={Y(base)} stroke="var(--ac)" strokeDasharray="2 4" />
      <polyline fill="none" stroke="var(--r)" strokeWidth="2" points={pts(s.m)} />
    </svg>
    <div className="mu">Red: {s.name}’s Maths. Teal dots: own usual level ({base}). Grey: class average.</div>
  </>);
}

function Teacher({ open }) {
  const [p, setP] = useState(null), [err, setErr] = useState(false);
  const load = () => { setErr(false); api("/plan").then(setP).catch(() => setErr(true)); };
  useEffect(load, []);
  if (err) return <Err retry={load} />;
  if (!p) return <p>Loading…</p>;
  return (<>
    <h3>Today’s support list</h3><div className="mu">{p.budget}-minute budget · {p.used} min planned · capped at 3</div>
    {p.items.map((i) => (<div className="card" key={i.id}>
      <div className="row"><b>{i.name}</b><Pill l={i.lvl} /></div>
      <ul>{i.why.map((w) => <li key={w.t}>{w.t}</li>)}</ul>
      <div className="row"><span className="mu">Next step: {i.action} ({i.minutes} min of your time)</span><button onClick={() => open(i.id)}>Open</button></div>
    </div>))}
    <h3>Not on today’s list</h3>
    {p.others.map((o) => <div className="card row" key={o.id}><span>{o.name} <span className="mu">({o.sec})</span></span><span className="mu">{o.note}</span></div>)}
  </>);
}

function StudentPage({ id }) {
  const [d, setD] = useState(null), [lang, setLang] = useState("en"), [att, setAtt] = useState(null), [err, setErr] = useState(false);
  const load = (a) => api(`/students/${id}${a ? `?att=${a}` : ""}`).then((x) => { setErr(false); setD(x); if (!a) setAtt(x.a.att); }).catch(() => setErr(true));
  useEffect(() => { load(); }, [id]);
  if (err) return <Err retry={() => load(att)} />;
  if (!d) return <p>Loading…</p>;
  const { student: s, a, notes, actions } = d, n = notes[lang];
  const log = async (t) => { await post(`/students/${id}/actions`, { text: t }); load(att); };
  return (<>
    <div className="card"><div className="row"><h3 style={{ margin: 0 }}>{s.name} · Section {s.sec}</h3><Pill l={a.lvl} /></div>
      <Chart s={s} base={a.base} classAvg={d.classAvg} /></div>
    <div className="card"><b>Top reasons</b>
      <ul>{a.why.length ? a.why.map((w) => <li key={w.t}>{w.t}</li>) : <li>Within own usual range</li>}</ul>
      <b>What-if: attendance {att}%</b>
      <input type="range" aria-label="What-if attendance percent" min="60" max="100" value={att ?? 90} onChange={(e) => { setAtt(+e.target.value); load(+e.target.value); }} />
    </div>
    <div className="card"><div className="row"><b>Parent note</b>
      <span><button className={lang === "en" ? "on" : ""} onClick={() => setLang("en")}>English</button> <button className={lang === "ta" ? "on" : ""} onClick={() => setLang("ta")}>தமிழ்</button></span></div>
      <p className="note">{n.text}</p>
      <div className="mu">Validator: numbers match source {n.numbersOk ? "✓" : "✗"} · no blame or labels {n.noBlame ? "✓" : "✗"}{lang === "ta" ? ". Tamil is a draft pending native-speaker review." : ""}</div>
      {s.approved ? <p><b>Approved by teacher.</b> <span className="mu">Prototype sends nothing.</span></p>
        : <p><button disabled={!n.valid} onClick={async () => { await post(`/students/${id}/approve`); load(att); }}>Approve note</button> <span className="mu">Nothing is sent without approval.</span></p>}
    </div>
    <div className="card"><b>Log an action</b>
      <p>{["Practice session (10 min)", "Parent call (10 min)", "Peer help (5 min)"].map((t) => <button key={t} onClick={() => log(t)} style={{ marginRight: 6 }}>{t.split(" (")[0]}</button>)}</p>
      <ul>{actions.length ? actions.map((x) => <li key={x._id}>{new Date(x.at).toLocaleDateString()}: {x.text}</li>) : <li className="mu">No actions logged yet</li>}</ul>
      <div className="mu">Real outcome tracking would say “looks helpful”, never “proven”.</div></div>
  </>);
}

function Admin() {
  const [d, setD] = useState(null), [err, setErr] = useState(false), [csv, setCsv] = useState(""), [msg, setMsg] = useState(null);
  const load = () => { setErr(false); api("/admin").then(setD).catch(() => setErr(true)); };
  useEffect(load, []);
  const send = async () => {
    try { const r = await post("/upload", { csv }); setMsg({ ok: true, t: `Added ${r.added} students.` }); setCsv(""); load(); }
    catch (e) { setMsg({ ok: false, t: (e.data?.errors || [e.message]).join(" | ") }); }
  };
  if (err) return <Err retry={load} />;
  if (!d) return <p>Loading…</p>;
  const col = (x) => (x <= -10 ? "#ef4444" : x <= -5 ? "#f59e0b" : x >= 3 ? "#22c55e" : "#9ca3af");
  return (<>
    <h3>Maths change from each student’s own usual level</h3>
    <div className="scroll"><table><tbody>{d.heat.map((r) => <tr key={r.name + r.sec}><th style={{ textAlign: "left" }}>{r.name} {r.sec}</th>{r.delta.map((v, i) => <td key={i} style={{ background: col(v), color: "#111" }}>{v > 0 ? "+" : ""}{v}</td>)}</tr>)}</tbody></table></div>
    <div className="card">Flag rate: Section A {d.flagRate.A}% · Section B {d.flagRate.B}%<br /><span className="mu">Two sections of synthetic data only. Real groups need real data and a review trigger.</span></div>
    <div className="card">Actions logged: {d.actions}</div>
    <div className="card"><b>Add students from CSV</b>
      <div className="mu">Columns: name, section, m1 to m8, a1 to a8, mondays, homework. Bad rows are reported, never scored.</div>
      <p><input type="file" accept=".csv,text/csv" aria-label="Choose CSV file" onChange={(e) => e.target.files[0]?.text().then(setCsv)} /></p>
      <textarea aria-label="CSV text" rows="4" style={{ width: "100%" }} value={csv} onChange={(e) => setCsv(e.target.value)} />
      <p><button disabled={!csv.trim()} onClick={send}>Validate and add</button></p>
      {msg && <div role="status" style={{ color: msg.ok ? "var(--ac)" : "var(--r)" }}>{msg.t}</div>}
    </div>
  </>);
}

function Growth() {
  return (<div className="card"><h3 style={{ margin: 0 }}>Your Growth Journey</h3>
    <p>Science is steady. In Maths, your last two tests were a little below your usual level, so a few short practice sessions could help you get back there.</p>
    <div className="mu">Students see personal progress only. No labels, no leaderboards. Schools can switch this view off.</div></div>);
}

export default function App() {
  const [role, setRole] = useState("Teacher"), [sid, setSid] = useState(null), [kid, setKid] = useState(null);
  useEffect(() => { api("/plan").then((p) => setKid(p.items[0]?.id)); }, []);
  const view = role === "Teacher" ? (sid ? <><button onClick={() => setSid(null)}>← List</button><StudentPage id={sid} /></> : <Teacher open={setSid} />)
    : role === "Parent" ? (kid ? <StudentPage id={kid} /> : <p>Loading…</p>) : role === "Student" ? <Growth /> : <Admin />;
  return (<main><h2 style={{ margin: "4px 0" }}>EduPulse <span className="mu">MERN prototype</span></h2>
    <div className="mu">Synthetic demo data. Nothing is sent to anyone.</div>
    <div className="tabs">{["Teacher", "Parent", "Student", "Admin"].map((r) => <button key={r} className={r === role ? "on" : ""} onClick={() => { setRole(r); setSid(null); }}>{r}</button>)}</div>
    {view}</main>);
}
