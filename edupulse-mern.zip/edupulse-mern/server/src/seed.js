let seed = 42;
const R = () => (seed = (seed * 16807) % 2147483647) / 2147483647;
const jit = (a) => Math.round(a + (R() - 0.5) * 6);
const PEOPLE = [["Meena","A","ok"],["Arjun","A","att"],["Divya","A","ok"],["Suresh","A","hw"],["Lakshmi","A","ok"],["Imran","B","ok"],["Priya","B","slip"],["Vikram","B","ok"],["Anjali","B","ok"],["Ravi","B","att"],["Nisha","B","ok"]];
export function makeStudents() {
  const out = [{ name: "Karthik", sec: "A", m: [74,73,75,72,68,64,61,60], s: [80,82,79,81,83,80,82,81], att: [96,95,96,94,92,90,88,86], mon: 4, hw: 64, kind: "slip" }];
  for (const [name, sec, t] of PEOPLE) {
    const base = [48, 55, 62, 70, 76][Math.floor(R() * 5)];
    const m = [...Array(8)].map((_, k) => jit(base - (t === "slip" && k > 3 ? (k - 3) * 3 : 0) - (t === "att" && k > 4 ? (k - 4) * 2 : 0)));
    const s = [...Array(8)].map(() => jit(base + 6));
    const att = [...Array(8)].map((_, k) => Math.round(94 + (R() - 0.5) * 4 - (t === "att" && k > 3 ? (k - 3) * 4 : 0) - (t === "slip" && k > 3 ? k - 3 : 0)));
    out.push({ name, sec, kind: t, m, s, att, mon: t === "att" ? 4 : Math.floor(R() * 2), hw: t === "hw" ? 45 : t === "slip" ? 65 : t === "att" ? 70 : 85 + Math.floor(R() * 10) });
  }
  return out;
}
