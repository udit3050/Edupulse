// Week-by-week replay on the SYNTHETIC school. A sanity check of the rules, not an accuracy claim.
import { analyse } from "./engine.js";
import { makeStudents } from "./seed.js";
// Monday and homework fields are static per term in the seed, so they are neutralised here: only marks and attendance vary over time.
const ONSET = { slip: 4, att: 4 }; // first test index where the planted problem exists
const rows = makeStudents().map((s) => {
  let first = null;
  for (let k = 4; k <= 8; k++) {
    const a = analyse({ ...s, mon: 0, hw: 90, m: s.m.slice(0, k), att: s.att.slice(0, k) });
    if (a.lvl > 0 && first === null) first = k;
  }
  return { name: s.name, kind: s.kind, first };
});
const planted = rows.filter((r) => r.kind === "slip" || r.kind === "att"), clean = rows.filter((r) => r.kind === "ok");
const caught = planted.filter((r) => r.first !== null);
const lead = caught.map((r) => r.first - 1 - ONSET[r.kind]);
console.log("SYNTHETIC REPLAY (12 students, 8 tests, marks and attendance only)");
rows.forEach((r) => console.log(r.name.padEnd(9), r.kind.padEnd(5), r.first === null ? "never flagged" : `first flagged after test ${r.first}`));
console.log(`Planted-problem students caught: ${caught.length}/${planted.length}`);
console.log(`Steady students wrongly flagged: ${clean.filter((r) => r.first !== null).length}/${clean.length}`);
console.log(`Tests between onset and first flag (caught only): ${lead.join(", ")}`);
