import "dotenv/config";
import express from "express";
import cors from "cors";
import mongoose from "mongoose";
import { analyse, makePlan, buildNote } from "./engine.js";
import { makeStudents } from "./seed.js";
import { parseCsv } from "./csv.js";

const Student = mongoose.model("Student", new mongoose.Schema({
  name: String, sec: String, m: [Number], s: [Number], att: [Number], mon: Number, hw: Number, approved: { type: Boolean, default: false },
}));
const Action = mongoose.model("Action", new mongoose.Schema({ studentId: mongoose.Schema.Types.ObjectId, text: String, at: { type: Date, default: Date.now } }));

const app = express();
app.use(cors(), express.json());
const avg = (a) => a.reduce((x, y) => x + y, 0) / a.length;
const wrap = (fn) => (req, res) => fn(req, res).catch((e) => res.status(500).json({ error: e.message }));
const rowsOf = async () => (await Student.find().lean()).map((s) => ({ s, a: analyse(s) }));

app.get("/api/plan", wrap(async (_req, res) => {
  const rows = await rowsOf(); const { items, used } = makePlan(rows);
  const picked = new Set(items.map((i) => String(i.s._id)));
  res.json({
    used, budget: 20,
    items: items.map((i) => ({ id: i.s._id, name: i.s.name, sec: i.s.sec, lvl: i.a.lvl, why: i.a.why, action: i.action, minutes: i.minutes })),
    others: rows.filter((r) => !picked.has(String(r.s._id))).map((r) => ({ id: r.s._id, name: r.s.name, sec: r.s.sec, lvl: r.a.lvl, note: r.a.lvl ? "Flagged, over time budget" : "Why not flagged: within own usual range" })),
  });
}));

app.get("/api/students/:id", wrap(async (req, res) => {
  const [s, all, actions] = await Promise.all([Student.findById(req.params.id).lean(), Student.find().lean(), Action.find({ studentId: req.params.id }).sort("at").lean()]);
  if (!s) return res.status(404).json({ error: "not found" });
  const att = req.query.att ? Number(req.query.att) : undefined; // what-if slider
  res.json({ student: s, a: analyse(s, att), classAvg: s.m.map((_, k) => Math.round(avg(all.map((x) => x.m[k])))), notes: { en: buildNote(s, "en"), ta: buildNote(s, "ta") }, actions });
}));

app.post("/api/students/:id/approve", wrap(async (req, res) => {
  const s = await Student.findById(req.params.id);
  if (!buildNote(s).valid) return res.status(400).json({ error: "validator failed" });
  s.approved = true; await s.save(); res.json({ approved: true }); // a real build would queue the send here
}));

app.post("/api/students/:id/actions", wrap(async (req, res) => {
  const text = String(req.body.text || "").slice(0, 120);
  res.json(await Action.create({ studentId: req.params.id, text }));
}));

app.post("/api/upload", wrap(async (req, res) => {
  const { rows, errors } = parseCsv(req.body.csv);
  if (errors.length) return res.status(400).json({ error: "Validation failed", errors: errors.slice(0, 10) });
  await Student.insertMany(rows); res.json({ added: rows.length });
}));

app.get("/api/admin", wrap(async (_req, res) => {
  const rows = await rowsOf();
  const rate = (sec) => { const g = rows.filter((r) => r.s.sec === sec); return Math.round((100 * g.filter((r) => r.a.lvl > 0).length) / g.length); };
  res.json({ heat: rows.map((r) => ({ name: r.s.name, sec: r.s.sec, delta: r.s.m.map((v) => v - r.a.base) })), flagRate: { A: rate("A"), B: rate("B") }, actions: await Action.countDocuments() });
}));

await mongoose.connect(process.env.MONGO_URI || "mongodb://127.0.0.1:27017/edupulse");
if ((await Student.countDocuments()) === 0) await Student.insertMany(makeStudents());
app.listen(process.env.PORT || 5000, () => console.log("EduPulse API ready"));
