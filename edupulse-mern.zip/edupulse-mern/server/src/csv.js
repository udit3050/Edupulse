// CSV ingestion with validation: bad rows are reported, never silently scored.
const NEED = ["name", "section", ...[...Array(8)].map((_, i) => `m${i + 1}`), ...[...Array(8)].map((_, i) => `a${i + 1}`), "mondays", "homework"];
const inRange = (v, lo, hi) => v !== "" && v !== undefined && Number.isFinite(Number(v)) && Number(v) >= lo && Number(v) <= hi;

export function parseCsv(text) {
  const lines = String(text || "").trim().split(/\r?\n/).filter(Boolean);
  if (lines.length < 2) return { rows: [], errors: ["File needs a header row and at least one student"] };
  const head = lines.shift().split(",").map((h) => h.trim().toLowerCase());
  const missing = NEED.filter((h) => !head.includes(h));
  if (missing.length) return { rows: [], errors: [`Missing columns: ${missing.join(", ")}`] };
  const rows = [], errors = [];
  lines.forEach((line, i) => {
    const c = line.split(","); const o = Object.fromEntries(head.map((h, j) => [h, c[j]?.trim()]));
    const bad = [];
    if (!o.name) bad.push("name is empty");
    if (!o.section) bad.push("section is empty");
    NEED.filter((h) => /^[ma]\d$/.test(h) || h === "homework").forEach((h) => { if (!inRange(o[h], 0, 100)) bad.push(`${h} must be 0 to 100`); });
    if (!inRange(o.mondays, 0, 5)) bad.push("mondays must be 0 to 5");
    if (bad.length) return errors.push(`Row ${i + 2}: ${bad.slice(0, 3).join(", ")}`);
    rows.push({ name: o.name, sec: o.section, m: [1,2,3,4,5,6,7,8].map((k) => Number(o[`m${k}`])), s: [], att: [1,2,3,4,5,6,7,8].map((k) => Number(o[`a${k}`])), mon: Number(o.mondays), hw: Number(o.homework) });
  });
  return { rows, errors };
}
