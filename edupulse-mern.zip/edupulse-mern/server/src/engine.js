const avg = (a) => a.reduce((x, y) => x + y, 0) / a.length;
export const ACT = { marks: ["Set short remedial practice", 5], att: ["Parent call", 10], hw: ["Peer help pairing", 5] };

// Change-from-Self, Step A: transparent rules over a student's own history.
export function analyse(s, attOverride) {
  const base = Math.round(avg(s.m.slice(0, 4)));
  const recent = Math.round(avg(s.m.slice(-2)));
  const drop = base - recent;
  const att = attOverride ?? Math.round(avg(s.att.slice(-3)));
  const attDrop = Math.round(avg(s.att.slice(0, 3))) - att;
  let pts = 0; const why = [];
  if (drop >= 10) { pts += 2; why.push({ k: "marks", t: `Maths down ${drop} marks from their usual level of ${base}` }); }
  else if (drop >= 5) { pts += 1; why.push({ k: "marks", t: `Maths down ${drop} marks from their usual level of ${base}` }); }
  if (att < 85 || attDrop >= 8) { pts += 1; why.push({ k: "att", t: `Attendance ${att}%, down ${Math.max(attDrop, 0)} points from earlier` }); }
  if (s.mon >= 3) { pts += 1; why.push({ k: "att", t: `${s.mon} Monday absences in 5 weeks` }); }
  if (s.hw < 60) { pts += 1; why.push({ k: "hw", t: `Homework on time only ${s.hw}% of the time` }); }
  const lvl = pts >= 4 ? 3 : pts >= 2 ? 2 : pts >= 1 ? 1 : 0;
  return { base, recent, drop, att, pts, lvl, why: why.slice(0, 3) };
}

// Daily list: rank by points then size of drop, fill a teacher-time budget, cap the count.
export function makePlan(rows, budget = 20, cap = 3) {
  const flagged = rows.filter((r) => r.a.lvl > 0).sort((x, y) => y.a.pts - x.a.pts || y.a.drop - x.a.drop);
  let left = budget; const items = [];
  for (const r of flagged) {
    const [action, minutes] = ACT[r.a.why[0].k];
    if (items.length < cap && minutes <= left) { items.push({ ...r, action, minutes }); left -= minutes; }
  }
  return { items, used: budget - left };
}

// Parent note: facts -> fixed template -> validator. Nothing here sends anything.
export function buildNote(s, lang = "en") {
  const f = { name: s.name, mon: s.mon, dips: 3, mins: 10 };
  const text = lang === "ta"
    ? `${f.name} அறிவியலில் நன்றாகச் செய்து வருகிறார். கணிதத்தில் கடந்த ${f.dips} தேர்வுகளில் மதிப்பெண்கள் குறைந்துள்ளன, மேலும் ${f.mon} திங்கட்கிழமைகள் வரவில்லை. வீட்டில் ${f.mins} நிமிடம் பயிற்சி செய்தால் உதவும். இந்த வாரம் வகுப்பாசிரியர் அவரிடம் பேசுவார்.`
    : `${f.name} has been doing well in Science. In Maths, scores have dipped over the last ${f.dips} tests, and ${f.name} missed ${f.mon} Mondays. ${f.mins} minutes of practice at home could help. The class teacher will check in this week.`;
  const allowed = [f.mon, f.dips, f.mins];
  const numbersOk = (text.match(/\d+/g) || []).map(Number).every((n) => allowed.includes(n));
  const noBlame = !/risk|fail|weak|lazy|poor|ஆபத்து/i.test(text);
  return { text, numbersOk, noBlame, valid: numbersOk && noBlame };
}
