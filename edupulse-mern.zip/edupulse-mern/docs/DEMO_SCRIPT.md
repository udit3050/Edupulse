# 5-minute demo script (record a backup video of this by 24 Nov)

Before you start: run the app, open it on a phone-sized window, say once that all data is synthetic.

| Time | Do | Say (in your own words) |
| --- | --- | --- |
| 0:00 | Teacher tab, today’s list | “A teacher gets three students and one next step each, sized to a 20-minute budget.” |
| 0:45 | Open Karthik | “He is above class average all term, so a class-average rule misses him. Against his own usual level, the drop is clear.” |
| 1:30 | Move the what-if slider to 90 | “Better attendance lowers the level, so the reasoning is visible, not a black box.” |
| 2:15 | Parent note, switch to Tamil, approve | “Facts come from data, wording from a template, a validator checks numbers, a teacher approves. Nothing is sent.” |
| 3:00 | Log an action | “Actions are saved so we can later check whether students recover.” |
| 3:30 | Student tab, then Admin tab | “Students see growth only. Admins see a heatmap and a flag-rate comparison.” |
| 4:15 | Limits and next steps | “Synthetic data, rules only, no login yet. Next: real backtest, ML model, pilot.” |

Recording checklist: screen recorder on, mic check, 1080p, one take, no real student names, keep under 5:30.
If the live demo fails: play the video, then show the published prototype link.
