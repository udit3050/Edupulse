# EduPulse Round 3: Technical Documentation
Team tech gig: Roshni K, Udit Goel.

## What it does
Compares each student with their own earlier performance, ranks who needs support today within a 20-minute teacher budget, explains why in plain words, and drafts a parent note that a teacher must approve.

## Architecture
React (Vite) client, Express API, Mongoose models on MongoDB. `server/src/engine.js` holds the rules, planner and note validator and has no database dependency.

## How scoring works
Usual level = mean of the first four Maths tests. Drop = usual level minus mean of the last two. Points for a drop of 5+ (1) or 10+ (2), attendance under 85% or falling 8+ points, 3+ Monday absences, homework on time under 60%. Points map to support level 1 to 3.

## Implemented
Daily list, student page with chart, what-if attendance slider, English and Tamil notes with validator and approval, action log, CSV upload with row-level validation (`docs/sample.csv`), error and retry states, student growth view, admin heatmap and flag-rate comparison, engine tests (`npm test`), replay script (`node src/replay.js`).

## Measured so far (synthetic school only)
Replay of the seeded 12-student school, using marks and attendance only (Monday and homework values are static in the seed, so they are left out to avoid leakage):
- Planted slips caught: 4 of 4
- Steady students wrongly flagged: 0 of 7
- Flag came 1 to 3 tests after the planted problem began

This is a sanity check on data we generated ourselves, so it shows the rules behave as designed. It is not an accuracy claim. Real precision, recall and lead time need a backtest on public data (UCI Student Performance, OULAD), which is not done yet.

## Limitations
Synthetic data; rules only, no ML; thresholds untuned; no login or row-level security; Tamil template needs native review; fairness check covers two sections only; nothing is sent to parents.

## Future work
Backtest on public data and tune thresholds; gradient-boosting model with SHAP reasons; roles and security; CSV upload; ERP adapter (Prasunex first); one-school pilot with fairness review; more regional languages.

## Run
See README.md.
