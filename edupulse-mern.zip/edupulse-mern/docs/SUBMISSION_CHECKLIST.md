# Round 3 submission checklist

| Requirement | Evidence | Status |
| --- | --- | --- |
| Working prototype | MERN app in this repo; browser version at https://claude.ai/artifact/EuNqWUTV4GfuyrGK1W2gjo | Done |
| Live demo or video | `docs/DEMO_SCRIPT.md` | Script done. Record the video yourselves |
| Source code or repository | This folder | Upload to GitHub and paste the link here and on the last slide |
| Brief technical documentation | `docs/TECHNICAL_DOC.md` | Done |
| Implemented features and limitations | Technical doc and slide 6 | Done |
| Future plans | Technical doc and last content slide | Done |

| Evaluation criterion | Where it shows |
| --- | --- |
| Functionality and implementation quality | Rules engine with tests (`npm test`), CSV upload with row-level validation, saved approvals and actions, error and retry states |
| Technical execution | Separate engine module, REST API, validator on every parent note, replay script |
| User experience and usability | Four role views, 20-minute list capped at three, plain-language reasons, what-if slider, labelled inputs, light and dark mode, phone-width layout |
| Innovation and effectiveness | Compare-with-self scoring, “why not flagged”, safe-by-design messaging. Effectiveness is measured only on synthetic data so far |
| Practical applicability and scalability | Weekly batch scoring, engine separable behind an API, ERP adapter plan |
| Quality of demonstration | Timed script, backup video plan, published prototype as fallback |
